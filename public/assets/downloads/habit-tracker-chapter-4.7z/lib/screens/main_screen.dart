import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'add_edit_habit_screen.dart';
import '../controllers/habit_controller.dart';
import '../widgets/habit_list_item.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final HabitController controller = Get.put(HabitController());

    return Scaffold(
      appBar: AppBar(title: const Text('My Habits')),
      body: Obx(
        () => ListView.builder(
          itemCount: controller.habits.length,
          itemBuilder: (context, index) {
            final habit = controller.habits[index];
            return HabitListItem(
              habitName: habit.name,
              isCompleted: habit.isCompleted,
              onToggle: (value) => controller.toggleHabit(habit),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to the new screen
          Get.to(() => const AddEditHabitScreen());
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
