import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../models/habit.dart';

class HabitController extends GetxController {
  var habits = [].obs;
  final box = GetStorage();

  @override
  void onInit() {
    super.onInit();

    // Read the stored habits from the 'habits' key.
    List? storedHabits = box.read('habits');

    // If there are stored habits, parse them from JSON and load them.
    if (storedHabits != null) {
      habits.value = storedHabits.map((e) => Habit.fromJson(e)).toList();
    }

    // The dummy data from Chapter 2 is no longer needed, as we now
    // persist the user's actual data.

    // Use a GetX worker called 'ever'. It listens to the 'habits' list.
    // Every time the list is changed (add, remove, update), it saves
    // the entire list to storage.
    ever(habits, (_) {
      box.write('habits', habits.toList().map((e) => e.toJson()).toList());
    });
  }

  void addHabit(String name, String description) {
    if (name.isEmpty) return;
    final newHabit = Habit(name: name, description: description);
    // When we add a habit here, the 'ever' worker will automatically save it.
    habits.add(newHabit);
  }

  void toggleHabit(Habit habit) {
    habit.isCompleted = !habit.isCompleted;
    // When we toggle here, the 'ever' worker will also save the change.
    habits.refresh();
  }
}
