import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/habit_controller.dart';

class AddEditHabitScreen extends StatelessWidget {
  const AddEditHabitScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Create controllers
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final HabitController controller =
        Get.find(); // Find the existing controller instance

    return Scaffold(
      appBar: AppBar(title: const Text('Add New Habit')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController, // Attach controller
              decoration: const InputDecoration(labelText: 'Habit Name'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController, // Attach controller
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // Call the controller method
                controller.addHabit(
                  nameController.text,
                  descriptionController.text,
                );
                // Go back to the previous screen
                Get.back();
              },
              child: const Text('Save Habit'),
            ),
          ],
        ),
      ),
    );
  }
}
