import 'package:flutter/material.dart';

class HabitListItem extends StatelessWidget {
  final String habitName;
  final bool isCompleted;
  final Function(bool?)? onToggle;

  const HabitListItem({
    super.key,
    required this.habitName,
    required this.isCompleted,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(habitName),
      leading: Checkbox(value: isCompleted, onChanged: onToggle),
    );
  }
}
