import 'package:get/get.dart';
import '../models/habit.dart';

class HabitController extends GetxController {
  var habits = [].obs;

  @override
  void onInit() {
    super.onInit();
    habits.addAll([
      Habit(name: 'Read for 15 minutes', description: 'Expand the mind'),
      Habit(
        name: 'Go for a walk',
        description: 'Good for the body',
        isCompleted: true,
      ),
    ]);
  }

  void toggleHabit(Habit habit) {
    habit.isCompleted = !habit.isCompleted;
    habits.refresh();
  }

  void addHabit(String name, String description) {
    if (name.isEmpty) {
      // Optional: Show a snackbar or message if the name is empty
      return;
    }
    final newHabit = Habit(name: name, description: description);
    habits.add(newHabit);
  }
}
