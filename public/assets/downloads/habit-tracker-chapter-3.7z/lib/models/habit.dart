class Habit {
  final String name;
  final String description;
  bool isCompleted;

  Habit({
    required this.name,
    required this.description,
    this.isCompleted = false,
  });
}
